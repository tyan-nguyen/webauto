-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 08, 2023 at 08:39 AM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webauto`
--

-- --------------------------------------------------------

--
-- Table structure for table `technologies`
--

DROP TABLE IF EXISTS `technologies`;
CREATE TABLE IF NOT EXISTS `technologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
CREATE TABLE IF NOT EXISTS `template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template_blocks`
--

DROP TABLE IF EXISTS `template_blocks`;
CREATE TABLE IF NOT EXISTS `template_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template_pages`
--

DROP TABLE IF EXISTS `template_pages`;
CREATE TABLE IF NOT EXISTS `template_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_dynamic` tinyint(1) NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template_technologies`
--

DROP TABLE IF EXISTS `template_technologies`;
CREATE TABLE IF NOT EXISTS `template_technologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `id_technologie` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`),
  KEY `id_technologie` (`id_technologie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template_varibles`
--

DROP TABLE IF EXISTS `template_varibles`;
CREATE TABLE IF NOT EXISTS `template_varibles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `varible_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `website`
--

DROP TABLE IF EXISTS `website`;
CREATE TABLE IF NOT EXISTS `website` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `date_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `website_blocks`
--

DROP TABLE IF EXISTS `website_blocks`;
CREATE TABLE IF NOT EXISTS `website_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_template_block` int(11) NOT NULL,
  `content` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_template_block` (`id_template_block`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `website_pages`
--

DROP TABLE IF EXISTS `website_pages`;
CREATE TABLE IF NOT EXISTS `website_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_templage_page` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_templage_page` (`id_templage_page`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `website_varibles`
--

DROP TABLE IF EXISTS `website_varibles`;
CREATE TABLE IF NOT EXISTS `website_varibles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_templage_varible` int(11) NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_templage_varible` (`id_templage_varible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `template_blocks`
--
ALTER TABLE `template_blocks`
  ADD CONSTRAINT `template_blocks_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_pages`
--
ALTER TABLE `template_pages`
  ADD CONSTRAINT `template_pages_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_technologies`
--
ALTER TABLE `template_technologies`
  ADD CONSTRAINT `template_technologies_ibfk_1` FOREIGN KEY (`id_technologie`) REFERENCES `technologies` (`id`),
  ADD CONSTRAINT `template_technologies_ibfk_2` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_varibles`
--
ALTER TABLE `template_varibles`
  ADD CONSTRAINT `template_varibles_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `website`
--
ALTER TABLE `website`
  ADD CONSTRAINT `website_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `website_blocks`
--
ALTER TABLE `website_blocks`
  ADD CONSTRAINT `website_blocks_ibfk_1` FOREIGN KEY (`id_template_block`) REFERENCES `template_blocks` (`id`),
  ADD CONSTRAINT `website_blocks_ibfk_2` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`);

--
-- Constraints for table `website_pages`
--
ALTER TABLE `website_pages`
  ADD CONSTRAINT `website_pages_ibfk_1` FOREIGN KEY (`id_templage_page`) REFERENCES `template_pages` (`id`),
  ADD CONSTRAINT `website_pages_ibfk_2` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`);

--
-- Constraints for table `website_varibles`
--
ALTER TABLE `website_varibles`
  ADD CONSTRAINT `website_varibles_ibfk_1` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`),
  ADD CONSTRAINT `website_varibles_ibfk_2` FOREIGN KEY (`id_templage_varible`) REFERENCES `template_varibles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
